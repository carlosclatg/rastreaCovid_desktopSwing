package com.ioc.rastreacovid.mappers;

public class DeleteUser {

}
