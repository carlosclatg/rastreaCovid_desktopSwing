package com.ioc.rastreacovid.screens;

import com.ioc.rastreacovid.communication.ApiConnector;
import com.ioc.rastreacovid.mappers.Id;
import com.ioc.rastreacovid.mappers.PatientPost;
import com.ioc.rastreacovid.mappers.UserPost;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.prefs.Preferences;

public class CreatePatientScreen implements ActionListener {

	// Components of the Form
	private JLabel title;
	private JLabel name;
	private JLabel surname;
	private JTextField tname;
	private JTextField tsurname;
	private JLabel birthdate;
	private JTextField tbirthdate;
	private JLabel pcrdate;
	private JTextField tpcrdate;
	private JLabel phone;
	private JTextField tphone;
	private JButton sub;
	private JButton reset;
	private JLabel res;
	private JFrame frame;
	private JButton sym;
	
	private String rolselected;
	
	
	/**
	 * Ejemplo de creación de PatientPost: PatientPost pp = new PatientPost();
	 * pp.setName("Carlos"); pp.setSurname("Calvo"); pp.setBirthDate(1000000);
	 * pp.setPhone(890765123); pp.setPCRDate(10000000); List<String> sin = new
	 * ArrayList<String>(); sin.add("60684ba4c609df2b79a8879c"); //los obtienes de
	 * hacer un getsintoms sin.add("606b104c0216041e56299365");
	 * sin.add("60684c70c609df2b79a887a0"); pp.setSintoms(sin); pp.setContacts(new
	 * ArrayList<ContactWithoutId>()); List<ContactWithoutId> contacts = new
	 * ArrayList<ContactWithoutId>(); contacts.add(new ContactWithoutId("Donald",
	 * "Trump", 666888111)); pp.setContacts(contacts);
	 * ApiConnector.postPacient(token, pp);
	 */
	

	public CreatePatientScreen() {
		initialize();
	}

	// Initialize the contents of the frame.

	public void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(92, 255, 208));
		frame.setBounds(100, 100, 1050, 500);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Dispose on close, otherwise closes all the app

		frame.setTitle("Creació de pacient");
		Preferences prefs = Preferences.userNodeForPackage(LoginForm.class);
		String token = prefs.get("token", "token");

		frame.setTitle("Creació de pacient");
		frame.setBounds(300, 90, 500, 500);

		title = new JLabel("Creació de pacient");
		title.setFont(new Font("Lucida Grande", Font.PLAIN, 25));
		title.setSize(235, 30);
		title.setLocation(150, 20);
		frame.add(title);

		name = new JLabel("Nom:");
		name.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		name.setSize(100, 20);
		name.setLocation(100, 80);
		frame.add(name);

		tname = new JTextField();
		tname.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		tname.setSize(190, 20);
		tname.setLocation(200, 80);
		frame.add(tname);

		surname = new JLabel("Cognom:");
		surname.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		surname.setSize(100, 20);
		surname.setLocation(100, 120);
		frame.add(surname);

		tsurname = new JTextField();
		tsurname.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		tsurname.setSize(190, 20);
		tsurname.setLocation(200, 120);
		frame.add(tsurname);

		birthdate = new JLabel("Data de naixement:");
		birthdate.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		birthdate.setSize(100, 20);
		birthdate.setLocation(100, 160);
		frame.add(birthdate);

		tbirthdate = new JTextField();
		tbirthdate.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		tbirthdate.setSize(190, 20);
		tbirthdate.setLocation(200, 160);
		frame.add(tbirthdate);

		pcrdate = new JLabel("Data de la PCR:");
		pcrdate.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		pcrdate.setSize(100, 20);
		pcrdate.setLocation(100, 200);
		frame.add(pcrdate);

		tpcrdate = new JTextField();
		tpcrdate.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		tpcrdate.setSize(190, 20);
		tpcrdate.setLocation(200, 200);
		frame.add(tpcrdate);

		phone = new JLabel("Telèfon:");
		phone.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		phone.setSize(100, 20);
		phone.setLocation(100, 240);
		frame.add(phone);

		tphone = new JTextField();
		tphone.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		tphone.setSize(190, 20);
		tphone.setLocation(200, 240);
		frame.add(tphone); 
		
		
		sym = new JButton("Afegir Símptoma");
		sym.setBackground(new Color(255, 255, 255));
		sym.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		sym.setSize(100, 20);
		sym.setLocation(130, 420);
		sym.addActionListener(this);
		frame.add(sym);
		sym.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				CreatePatientScreen screen = new CreatePatientScreen();
				screen.getFrame().setVisible(true);
			}
		});
		

		sub = new JButton("Aceptar");
		sub.setBackground(new Color(255, 255, 255));
		sub.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		sub.setSize(100, 20);
		sub.setLocation(130, 420);
		sub.addActionListener(this);
		frame.add(sub);

		reset = new JButton("Reset");
		reset.setBackground(new Color(255, 255, 255));
		reset.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		reset.setSize(100, 20);
		reset.setLocation(250, 420);
		reset.addActionListener(this);
		frame.add(reset);

		res = new JLabel("");
		res.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		res.setSize(500, 25);
		res.setLocation(100, 500);
		frame.add(res);

		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == reset) {
			String def = "";
			tname.setText(def);
			tsurname.setText(def);
			tbirthdate.setText(def);
			tpcrdate.setText(def);
			tphone.setText(def);
		} else if (e.getSource() == sub) {
			tname.setText(tname.getText());
			tsurname.setText(tsurname.getText());
			tbirthdate.setText(tbirthdate.getText());
			tpcrdate.setText(tpcrdate.getText());
			tphone.setText(tphone.getText());

			
	

		}
		

		String sname = tname.getText();
		String ssurname = tsurname.getText();
		int sbirthdate = Integer.parseInt(tbirthdate.getText());
		int spcrdate = Integer.parseInt(tpcrdate.getText());
		int sphone = Integer.parseInt(tphone.getText());
		


		Preferences prefs = Preferences.userNodeForPackage(LoginForm.class);
		String token = prefs.get("token", "token");
		PatientPost pp = new PatientPost();
		pp.setName(sname);
		pp.setSurname(ssurname);
		pp.setPhone(sphone);
		pp.setBirthDate(sbirthdate);
		pp.setPCRDate(spcrdate);
	
		
		Id id = ApiConnector.postPacient(token, pp);

		if(id != null){
			JOptionPane.showMessageDialog(null, "El Pacient s'ha creat amb exit");
		} else {
			JOptionPane.showMessageDialog(null, "Ooops something went wrong");
		}

		


	}

	public Window getFrame() {
		return frame;
	}

}
