# rastreaCovid_desktop
#rastreaCovid

_Desktop version of the Rastreacovid application for user management.

# Run:
_From the folder containing the project:
_1. Browse for the "App.java" file.
_2. Run

# Manual Test:
_From the folder containing the project:
_1. Browse for the "App.java" file.
_2. Run
_3. You have to enter an e-mail address and a password. The system will validate that both are correct.
    If it is correct, another window will appear informing you of the token and with the possibility to log out.
    If you click on "log out" you will return to the previous window.
    If the data entered is not correct, you will get an alert informing you that it is incorrect.

# Automated unit tests:
_From the folder containing the project:
_1. Browse for the "AppTest.java" file.
_2. You can test the complete file or by method.
_3. Each method checks a different use case.

# Developed with
_Netbeans
_Visual Studio Code

# Version
_RastreaCovid 1.0
_RastreaCovid

# Author
_Rocio Bernabé